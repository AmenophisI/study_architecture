console.log('Hello TypeScript')
